def say_hello
  puts 'Привет, смешной мир!'
end
