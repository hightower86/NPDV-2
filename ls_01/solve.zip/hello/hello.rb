require_relative './requires/method.rb'

say_hello
